import React, { useState, useEffect } from "react";
import EventList from "../components/EventList";
import { useDispatch } from "react-redux";
import { setCity } from "../redux/cityReducer";
import InputLabel from "@mui/material/InputLabel";
import MenuItem from "@mui/material/MenuItem";
import FormControl from "@mui/material/FormControl";
import Select from "@mui/material/Select";
import { Box } from "@mui/material";
import "./HomePage.css";
import Banner from '../components/Banner';

const HomePage = () => {
  const [selectedCity, setSelectedCity] = useState("Jaipur");
  const dispatch = useDispatch();

  useEffect(()=>{
    dispatch(setCity("Jaipur"))
  },[])

  const handleSelect = (e) => {
    setSelectedCity(e.target.value);
    dispatch(setCity(e.target.value));
  };

  return (
    <div className="homepage">
        
        <Box className="location_text">
        <FormControl fullWidth>
          <InputLabel id="select-a-city" className="location_text">
            Select a City
          </InputLabel>
          <Select
            className="location_text"
            labelId="select-a-city"
            id="select-a-city"
            value={selectedCity}
            label="Select a City"
            onChange={handleSelect}
          >
            <MenuItem value="Jaipur">Jaipur</MenuItem>
            <MenuItem value="Gurugram">Gurugram</MenuItem>
            <MenuItem value="Pune">Pune</MenuItem>
            <MenuItem value="Bangalore">Bangalore</MenuItem>
            <MenuItem value="Hyderabad ">Hyderabad</MenuItem>
            <MenuItem value="Chennai">Chennai</MenuItem>
          </Select>
        </FormControl>
      </Box>
        <Banner image="./home_img.jpg" />
      

      {selectedCity && (
        <>
          <h1>Events</h1>
          <EventList />
        </>
      )}
     
    </div>
  );
};

export default HomePage;
