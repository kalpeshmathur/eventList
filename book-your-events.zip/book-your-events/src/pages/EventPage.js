import React from 'react';
import EventDetail from '../components/EventDetail';

const EventPage = () => {
    return (
        <div>
            <EventDetail />
        </div>
    );
};

export default EventPage;
