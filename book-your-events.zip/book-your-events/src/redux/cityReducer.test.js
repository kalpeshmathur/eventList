import cityReducer, { setCity } from './cityReducer';

test('should return the initial state', () => {
    expect(cityReducer(undefined, {})).toEqual({ city: '' });
});

test('should handle SET_CITY', () => {
    expect(cityReducer({ city: '' }, setCity('Jaipur'))).toEqual({ city: 'Jaipur' });
});
