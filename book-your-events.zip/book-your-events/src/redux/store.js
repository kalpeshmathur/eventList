import { createStore } from "redux";
import cityReducer from './cityReducer';

const store = createStore(cityReducer);

export default store;