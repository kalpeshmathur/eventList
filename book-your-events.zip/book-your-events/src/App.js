import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import { ThemeProvider, useTheme } from './contexts/ThemeContext';
import HomePage from './pages/HomePage';
import EventPage from './pages/EventPage';
import store from './redux/store';
import {Provider} from 'react-redux'
import './App.css';
import Header from './components/Header';
import Footer from './components/Footer';

const App = () => {
    const { theme } = useTheme();

    return (
        <Provider store={store}>
        <div className={`app ${theme}`}>
            <Router>
            <Header/>             
                <Routes>
                    <Route path="/" element={<HomePage />} />
                    <Route path="/event/:id" element={<EventPage />} />
                </Routes>
            </Router>
            <Footer />
        </div>
        </Provider>
    );
};

// eslint-disable-next-line import/no-anonymous-default-export
export default () => (
    <ThemeProvider>
        <App />
    </ThemeProvider>
);
