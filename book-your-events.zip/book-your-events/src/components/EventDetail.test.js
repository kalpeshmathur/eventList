import React from 'react';
import { render, screen } from '@testing-library/react';
import { BrowserRouter as Router } from 'react-router-dom';
import { useParams } from 'react-router-dom';
import EventDetail from './EventDetail';

// Mock useParams from react-router-dom
jest.mock('react-router-dom', () => ({
    ...jest.requireActual('react-router-dom'),
    useParams: jest.fn(),
}));

// Mock useParams to return a specific event ID
useParams.mockReturnValue({ id: '1' });


// Mock event data
const mockEvent = { id: 1, name: 'Sample Event', date: '2024-06-10', description: 'This is a sample event' };

// Mock the fetch function within EventDetail component
jest.mock('./EventDetail', () => (props) => {
    const { event } = props;
    return (
        <>           
            <div>
                <h1>{event.name}</h1>
                <p>{event.date}</p>
                <p>{event.description}</p>
            </div>
        </>
    );
});

test('fetches and displays event details', async () => {
    render(
       
            <Router>
                <EventDetail event={mockEvent} />
            </Router>
       
    );

    expect(screen.getByText('Sample Event')).toBeInTheDocument();
    expect(screen.getByText('2024-06-10')).toBeInTheDocument();
    expect(screen.getByText('This is a sample event')).toBeInTheDocument(); 
});
