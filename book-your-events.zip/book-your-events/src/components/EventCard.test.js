import React from 'react';
import { render, screen } from '@testing-library/react';
import { BrowserRouter as Router } from 'react-router-dom';
import EventCard from './EventCard';

test('renders event card with event details', () => {
    const event = { id: 1, name: 'Sample Event', date: '2024-06-10' };
    
    render(
        <Router>
            <EventCard event={event} />
        </Router>
    );

    expect(screen.getByText('Sample Event')).toBeInTheDocument();
    expect(screen.getByText('2024-06-10')).toBeInTheDocument();
    expect(screen.getByText('View Details')).toBeInTheDocument();
});
