import React from 'react';
import { Link } from 'react-router-dom';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import Typography from '@mui/material/Typography';
import './EventCard.css';

const EventCard = ({ event }) => {
    return (
        <Card className="event-card">
            <img src={event.image} alt={event.name} className="event-card-image" />
            <CardContent className="event-card-content">
                <Typography variant="h5" className="event-card-title">{event.name}</Typography>
                <Typography variant="body2" className="event-card-date">{event.date}</Typography>
                <Link to={`/event/${event.id}`} className="event-card-link">View Details</Link>
            </CardContent>
        </Card>
    );
};

export default EventCard;
