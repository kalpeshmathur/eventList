import React from 'react';
import { Link } from 'react-router-dom';
import './Header.css';
import ThemeToggle from './ThemeToggle';

const Header = () => {
    return (
        <header className="header">
            <div className="header-content">
                <nav className="nav-bar">
                    <Link to="/">Home</Link>
                    <Link to="/about">About</Link>
                    <Link to="/events">Events</Link>
                    <Link to="/contact">Contact</Link>
                </nav>
                <ThemeToggle />
            </div>
        </header>
    );
};

export default Header;
