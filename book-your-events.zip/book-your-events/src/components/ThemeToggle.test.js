import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import { ThemeProvider } from '../contexts/ThemeContext';
import ThemeToggle from './ThemeToggle';

test('toggles theme between light and dark', () => {
    render(
        <ThemeProvider>
            <ThemeToggle />
        </ThemeProvider>
    );

    const button = screen.getByText('Switch to dark mode');
    fireEvent.click(button);
    expect(screen.getByText('Switch to light mode')).toBeInTheDocument();
});
