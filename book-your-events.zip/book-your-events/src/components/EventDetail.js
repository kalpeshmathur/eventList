import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import axios from "axios";
import { useSelector } from "react-redux";
import "./EventDetail.css";

const EventDetail = () => {
  const { id } = useParams();
  let city = useSelector((state) => state.city);
  const [event, setEvent] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  useEffect(() => {
    axios
      .get("/event.json")
      .then((response) => {
        const foundEvent = response.data.find((e) => e.id === parseInt(id));
        setEvent(foundEvent);
      })
      .catch((error) => console.error(error));
  }, [id]);

  const handleButtonClick = () => {
    setIsModalOpen(true);
};

const handleCloseModal = () => {
    setIsModalOpen(false);
};

  if (!event) return <div>Loading...</div>;

  if(!city){
    city='Jaipur'
  }
  return (
    <>
    
      <div className="event-detail">
      <img src={event.image}/>
        <h5>Selected City is {city}</h5>
        <div className="event-info">
          <h4>{event.name}</h4>
          <p>{event.date}</p>
          <p>{event.description}</p>
        </div>
        <hr />
        <div>
          <h6>Location</h6>
          <p>{city}</p>
          <h6>Refund Policy</h6>
          <p>
            Contact the organizer to request a refund. Eventbrite's fee is
            nonrefundable.
          </p>
        </div>
        <hr />
        <button className="ticket-button" onClick={handleButtonClick}>$7 - $18 Tickets</button>
        <div className="event-about">
          <h6>About this event</h6>
          <p>Monday June 3rd</p>
          <p>
            Work by: David Simpatico, Suze Allen, Lisa Stathoplos & Christine
            Toy Johnson
          </p>
          <p>Some1Speaking. 1st Mondays at 6:30PM EST / 3:30PM PCT.</p>
          <p>
            On the first Monday of each month, Hear Me Out Monologues brings us
            5 unforgettable characters through 5 monologues written by 5
            extraordinary scriptwriters from all over the world. We gather in
            the Hear Me Out Zoom Black Box Theater for one hour of gripping
            theater.
          </p>
          <p>
            Following every Some1Speaking presentation, Roland Tec and Suze
            Allen stick around for 30 minutes to offer guidance to anyone
            interested in submitting a monologue to the annual Hear Me Out
            Monologue Competition. This is the perfect opportunity for you to
            check in with the festival directors for the inside scoop on exactly
            what qualities make for award-winning material.
          </p>
        </div>
        {isModalOpen && (
                <div className="modal">
                    <div className="modal-content">
                        <span className="close" onClick={handleCloseModal}>&times;</span>
                        <p>Your tickets are booked!</p>
                    </div>
                </div>
            )}
      </div>
    </>
  );
};

export default EventDetail;
