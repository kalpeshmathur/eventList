import React, { useEffect, useState } from 'react';
import axios from 'axios';
import EventCard from './EventCard';
import './EventList.css'

const EventList = () => {
    const [events, setEvents] = useState([]);

    useEffect(() => {
        axios.get('/event.json')
            .then(response => setEvents(response.data))
            .catch(error => console.error(error));
    }, []);

    return (
        <div className="event-list">
            {events.map(event => (
                <EventCard key={event.id} event={event} />
            ))}
        </div>
    );
};

export default EventList;
